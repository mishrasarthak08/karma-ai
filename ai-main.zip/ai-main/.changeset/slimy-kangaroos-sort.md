---
'@ai-sdk/xai': patch
---

feat (provider/xai): add grok-4 model id
