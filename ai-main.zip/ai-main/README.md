packages/ai/README.md
