---
'ai': patch
---

feat: provider-executed tools
