---
'ai': patch
---

feat (ai): add prepareSteps to streamText
