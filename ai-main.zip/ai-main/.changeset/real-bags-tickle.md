---
'ai': patch
---

fixed date formatting for updated mcp protocol version
