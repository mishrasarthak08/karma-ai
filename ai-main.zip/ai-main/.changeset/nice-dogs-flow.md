---
'ai': patch
---

feat (ai): step input message modification in prepareStep
