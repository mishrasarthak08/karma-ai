---
'@ai-sdk/google': patch
---

feat (providers/google): add thinking config to provider options
