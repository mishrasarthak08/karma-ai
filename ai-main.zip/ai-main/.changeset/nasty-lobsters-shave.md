---
'ai': major
---

chore (ai): remove redundant `mimeType` property
