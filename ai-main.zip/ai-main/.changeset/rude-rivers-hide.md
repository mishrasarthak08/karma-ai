---
'ai': major
---

chore (ai): remove steps from tool invocation ui parts
