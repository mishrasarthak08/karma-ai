---
'@example/next-openai-pages': patch
'@ai-sdk/openai-compatible': patch
'@example/sveltekit-openai': patch
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/provider-utils': patch
'@ai-sdk/google-vertex': patch
'@example/next-openai': patch
'@example/nuxt-openai': patch
'@ai-sdk/assemblyai': patch
'@ai-sdk/elevenlabs': patch
'@ai-sdk/perplexity': patch
'@ai-sdk/togetherai': patch
'@ai-sdk/anthropic': patch
'@ai-sdk/fireworks': patch
'@ai-sdk/replicate': patch
'@ai-sdk/cerebras': patch
'@ai-sdk/deepgram': patch
'@ai-sdk/deepseek': patch
'@example/ai-core': patch
'@ai-sdk/gateway': patch
'@ai-sdk/mistral': patch
'@ai-sdk/cohere': patch
'@ai-sdk/gladia': patch
'@ai-sdk/google': patch
'@ai-sdk/openai': patch
'@ai-sdk/svelte': patch
'@ai-sdk/react': patch
'@ai-sdk/revai': patch
'@ai-sdk/groq': patch
'@ai-sdk/hume': patch
'@ai-sdk/lmnt': patch
'@ai-sdk/luma': patch
'@example/mcp': patch
'@ai-sdk/fal': patch
'@ai-sdk/rsc': patch
'@ai-sdk/xai': patch
'ai': patch
---

feature: using Zod 4 for internal stuff
