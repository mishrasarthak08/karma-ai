---
'@ai-sdk/provider-utils': major
---

feat (ai): add output schema for tools
