---
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/mistral': patch
'@ai-sdk/cohere': patch
'@ai-sdk/openai': patch
'@ai-sdk/groq': patch
---

fix(providers): always use optional instead of mix of nullish for providerOptions
