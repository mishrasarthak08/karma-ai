---
'@ai-sdk/langchain': patch
---

chore(providers/langchain): extract to separate package
