---
'@ai-sdk/gateway': patch
---

fix (providers/gateway): fix timestamp error when streaming objects
