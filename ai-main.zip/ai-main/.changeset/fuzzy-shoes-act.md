---
'@ai-sdk/openai': patch
---

feat (providers/openai): add gpt-4.1 models
