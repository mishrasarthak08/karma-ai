---
'ai': major
---

chore (ai): refactor header preparation
