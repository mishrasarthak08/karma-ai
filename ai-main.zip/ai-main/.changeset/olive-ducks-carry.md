---
'@ai-sdk/provider': patch
'@ai-sdk/mistral': patch
'@ai-sdk/openai': patch
'@ai-sdk/azure': patch
'ai': patch
---

chore(embedding-models): remove remaining settings
