---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): add createGateway shorthand alias for createGatewayProvider
