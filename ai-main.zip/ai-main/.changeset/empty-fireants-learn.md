---
'ai': major
---

chore (ai): remove exports of internal ui functions
