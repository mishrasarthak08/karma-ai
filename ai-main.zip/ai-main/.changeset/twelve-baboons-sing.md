---
'@ai-sdk/google-vertex': patch
---

Add reasoning token output support for gemini models via Vertex AI Provider
