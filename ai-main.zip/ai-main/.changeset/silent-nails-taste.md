---
'@ai-sdk/google-vertex': patch
'@ai-sdk/anthropic': patch
---

fix (provider/google-vertex): fix anthropic support for image urls in messages
