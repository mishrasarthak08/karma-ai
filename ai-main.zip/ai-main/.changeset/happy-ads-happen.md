---
'ai': major
---

chore (ai): send reasoning to the client by default
