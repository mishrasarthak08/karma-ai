---
'@ai-sdk/google': patch
---

fix: omit system message for gemma models
