---
'@ai-sdk/cohere': patch
---

chore(providers/cohere): convert to providerOptions
