---
'@ai-sdk/fal': patch
---

feat (@ai-sdk/fal): support new Flux Kontext models
