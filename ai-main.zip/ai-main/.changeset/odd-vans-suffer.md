---
'@ai-sdk/xai': patch
---

chore (providers/xai): update grok-3 model aliases
