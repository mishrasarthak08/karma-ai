---
'ai': patch
---

fix (ai): fix sync tool execute with streamText
