---
'@ai-sdk/openai': patch
---

chore(providers/openai): re-introduce logprobs as providerMetadata
