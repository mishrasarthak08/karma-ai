---
'@ai-sdk/provider': patch
---

chore (provider): tweak provider definition
