---
'@ai-sdk/openai-compatible': patch
---

feat(providers/xai): add reasoningEffort provider option
