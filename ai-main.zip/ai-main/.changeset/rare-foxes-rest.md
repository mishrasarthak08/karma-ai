---
'ai': patch
---

feat (ui): add state for text and reasoning ui message parts
