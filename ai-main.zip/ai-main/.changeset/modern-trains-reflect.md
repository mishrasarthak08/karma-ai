---
'@ai-sdk/perplexity': major
---

feat(provider/perplexity): support image input
