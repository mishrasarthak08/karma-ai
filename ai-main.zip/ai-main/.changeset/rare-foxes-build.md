---
'ai': major
---

chore (ai): stable sendStart/sendFinish options
