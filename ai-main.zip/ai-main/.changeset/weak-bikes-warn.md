---
'@ai-sdk/anthropic': patch
---

add web search tool support
