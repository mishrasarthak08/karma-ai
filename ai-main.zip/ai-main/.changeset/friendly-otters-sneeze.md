---
'@ai-sdk/anthropic': patch
---

feat(anthropic/citation): text support for citations
