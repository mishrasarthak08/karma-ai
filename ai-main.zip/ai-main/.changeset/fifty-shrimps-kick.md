---
'@ai-sdk/google-vertex': patch
---

feat (google-vertex): Set `.providerMetaData` for image model responses
