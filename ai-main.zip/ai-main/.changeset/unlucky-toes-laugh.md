---
'@ai-sdk/cohere': patch
---

feat(cohere): add citations support for text documents
