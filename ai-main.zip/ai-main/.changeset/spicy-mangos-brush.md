---
'@ai-sdk/provider': major
---

chore: remove object generation mode
