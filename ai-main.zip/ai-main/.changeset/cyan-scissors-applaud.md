---
'@ai-sdk/openai': major
---

chore (provider/openai): switch default to openai responses api
