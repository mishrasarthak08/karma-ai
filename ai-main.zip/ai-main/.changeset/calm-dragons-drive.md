---
'ai': major
---

- remove setting temperature to `0` by default
- remove `null` option from `DefaultSettingsMiddleware`
- remove setting defaults for `temperature` and `stopSequences` in `ai` to enable middleware changes
