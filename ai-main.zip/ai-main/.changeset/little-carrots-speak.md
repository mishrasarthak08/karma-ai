---
'@ai-sdk/vercel': patch
---

feat (providers/vercel): initial vercel provider
