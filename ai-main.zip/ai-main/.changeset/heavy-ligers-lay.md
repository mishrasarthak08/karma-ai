---
'@ai-sdk/vue': patch
---

fix (ai-sdk/vue): fix status reactivity
