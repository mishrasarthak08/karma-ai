---
'@ai-sdk/provider': patch
'@ai-sdk/openai': patch
'@ai-sdk/azure': patch
'ai': patch
---

chore(providers/openai): enable structuredOutputs by default & switch to provider option
