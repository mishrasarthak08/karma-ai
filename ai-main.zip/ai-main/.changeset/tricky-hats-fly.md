---
'@ai-sdk/provider': patch
---

Remove `Experimental_LanguageModelV2Middleware` type
