---
'@ai-sdk/anthropic': patch
---

feat (provider/anthropic): enable streaming tool calls
