---
'ai': major
---

chore (ai): rename DataStream* to UIMessage*
