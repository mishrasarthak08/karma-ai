---
'@ai-sdk/provider': patch
---

chore (provider): extract LanguageModelV2File
