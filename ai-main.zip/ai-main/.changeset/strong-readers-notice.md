---
'@ai-sdk/provider': major
---

feat (provider): support arbitrary media types in tool results
