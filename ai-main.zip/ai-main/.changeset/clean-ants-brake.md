---
'@ai-sdk/svelte': major
'@ai-sdk/react': major
'@ai-sdk/vue': major
'ai': major
---

feat (ui): typed tool parts in ui messages
