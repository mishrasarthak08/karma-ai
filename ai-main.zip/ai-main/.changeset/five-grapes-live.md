---
'ai': patch
---

feat (ai): add readUIMessageStream helper
