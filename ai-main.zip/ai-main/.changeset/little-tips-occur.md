---
'ai': major
---

chore (ai): separate TextStreamChatTransport
