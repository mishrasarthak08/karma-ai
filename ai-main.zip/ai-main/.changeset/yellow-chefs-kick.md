---
'@ai-sdk/openai': patch
---

feat (providers/openai): support gpt-image-1 image generation
