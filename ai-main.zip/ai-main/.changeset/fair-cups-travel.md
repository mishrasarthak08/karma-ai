---
'@ai-sdk/revai': patch
---

feat(providers/revai): add transcribe
