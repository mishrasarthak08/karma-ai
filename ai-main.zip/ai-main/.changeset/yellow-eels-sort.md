---
'@ai-sdk/provider': patch
---

release alpha.10
