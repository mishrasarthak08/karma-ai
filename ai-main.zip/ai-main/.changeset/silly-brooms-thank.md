---
'ai': patch
---

feat (ai): add InferUITools helper
