---
'@ai-sdk/deepgram': patch
---

feat(providers/deepgram): add transcribe
