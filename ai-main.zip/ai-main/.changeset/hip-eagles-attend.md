---
'ai': major
---

chore (ai): replace `Message` with `UIMessage`
