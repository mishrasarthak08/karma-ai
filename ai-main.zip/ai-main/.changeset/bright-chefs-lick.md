---
'@ai-sdk/gateway': patch
---

feat (provider/gateway): update model ids
