---
'ai': patch
---

fix(react-native): support experimental_attachments without FileList global
