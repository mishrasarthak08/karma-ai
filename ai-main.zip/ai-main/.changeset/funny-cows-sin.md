---
'ai': patch
---

feat(streamObject): add enum support
