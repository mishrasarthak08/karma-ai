---
'@ai-sdk/provider-utils': patch
---

refactor (provider-utils): copy relevant code from `secure-json-parse` into codebase
