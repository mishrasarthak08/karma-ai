---
'@ai-sdk/provider': major
---

refactoring (provider): collapse provider defined tools into single definition
