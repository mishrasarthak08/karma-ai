---
'@ai-sdk/amazon-bedrock': patch
---

fix(bedrock): resolve mime-types of document and images
