---
'@ai-sdk/anthropic': patch
---

fix (provider/anthropic): return stop finish reason for json output with tool
