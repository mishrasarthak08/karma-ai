---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): add gateway error types with error detail
