---
'@ai-sdk/provider': major
---

chore: return content array from doGenerate (spec)
