---
'ai': patch
---

fix: avoid job executor deadlock when adding tool result
