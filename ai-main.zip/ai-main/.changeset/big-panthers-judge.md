---
'@ai-sdk/openai': patch
---

chore(providers/openai): convert to providerOptions
