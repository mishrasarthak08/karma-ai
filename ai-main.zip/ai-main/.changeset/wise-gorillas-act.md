---
'ai': patch
---

chore (ai): stable prepareStep
