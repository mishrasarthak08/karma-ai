---
'ai': patch
---

feat (ai): support string model ids through gateway
