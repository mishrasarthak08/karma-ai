---
'@ai-sdk/provider': major
---

chore (provider): rename providerMetadata inputs to providerOptions
