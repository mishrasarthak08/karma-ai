---
'ai': major
---

chore (ui): rename experimental_resume to resumeStream
