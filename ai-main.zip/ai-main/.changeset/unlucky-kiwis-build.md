---
'ai': major
---

chore (ai): remove ui message reasoning property
