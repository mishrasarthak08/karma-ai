---
'@ai-sdk/hume': patch
---

feat(providers/hume): add speech
