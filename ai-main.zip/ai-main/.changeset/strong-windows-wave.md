---
'@ai-sdk/react': patch
---

feat (ui/react): add resume flag to useChat
