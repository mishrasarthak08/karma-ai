---
'ai': major
---

feat (ai): restructure chat transports
