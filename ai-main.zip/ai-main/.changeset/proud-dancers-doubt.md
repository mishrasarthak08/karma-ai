---
'ai': patch
---

feat (ai): support changing the system prompt in prepareSteps
