---
'@ai-sdk/cohere': patch
---

fix (provider/cohere): tool calling
