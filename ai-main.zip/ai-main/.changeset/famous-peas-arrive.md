---
'ai': major
---

chore (ai): stable activeTools
