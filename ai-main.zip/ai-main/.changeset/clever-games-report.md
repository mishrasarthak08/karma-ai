---
'@ai-sdk/gladia': patch
---

fix (provider/gladia): correct workspace dependencies
