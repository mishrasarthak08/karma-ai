---
'ai': major
---

refactoring (ai): restructure message metadata transfer
