---
'@ai-sdk/provider-utils': patch
---

chore (provider-utils): use eventsource-parser library
