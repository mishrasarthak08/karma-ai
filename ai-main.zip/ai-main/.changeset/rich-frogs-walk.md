---
'ai': patch
---

feat (ai): allow async prepareRequest on HttpChatTransport
