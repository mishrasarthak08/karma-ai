---
'ai': major
---

chore (ai): remove "data" UIMessage role
