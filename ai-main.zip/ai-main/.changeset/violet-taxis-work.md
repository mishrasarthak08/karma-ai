---
'@ai-sdk/provider': major
'ai': major
---

chore: rename maxTokens to maxOutputTokens
