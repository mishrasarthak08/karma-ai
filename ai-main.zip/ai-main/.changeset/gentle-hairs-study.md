---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): include description and pricing info in model list
