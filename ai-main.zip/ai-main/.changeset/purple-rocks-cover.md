---
'@ai-sdk/openai': patch
'@ai-sdk/azure': patch
---

chore(providers/openai): remove & enable strict compatibility by default
