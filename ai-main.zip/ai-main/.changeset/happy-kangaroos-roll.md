---
'@ai-sdk/provider-utils': patch
'@ai-sdk/provider': patch
'@ai-sdk/openai': patch
'ai': patch
---

feat: add transcription with experimental_transcribe
