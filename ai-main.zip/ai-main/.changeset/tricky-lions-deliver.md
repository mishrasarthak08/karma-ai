---
'ai': patch
---

feat (ai): add consumeSseStream option to UI message stream responses
