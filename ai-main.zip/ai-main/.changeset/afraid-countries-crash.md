---
'@ai-sdk/elevenlabs': patch
---

fix(elevenlabs): use camelCase fileFormat in provider options
