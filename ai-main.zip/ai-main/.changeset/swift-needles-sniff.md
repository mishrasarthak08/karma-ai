---
'@ai-sdk/anthropic': patch
---

fix(anthropic): resolve web search API validation errors with partial location + provider output
