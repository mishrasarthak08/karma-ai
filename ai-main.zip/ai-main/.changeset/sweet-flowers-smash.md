---
'@ai-sdk/openai': patch
---

fix (provider/openai): handle responses api errors
