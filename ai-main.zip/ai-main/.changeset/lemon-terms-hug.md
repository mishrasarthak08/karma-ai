---
'ai': patch
---

fix(ai): remove jsondiffpatch dependency
