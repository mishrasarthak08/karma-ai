---
'ai': patch
---

fix (ai): fix experimental sendStart/sendFinish options in streamText
