---
'@ai-sdk/provider': patch
---

spec (ai): add provider options to tools
