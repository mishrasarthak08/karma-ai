---
'@ai-sdk/provider': major
---

chore: refactor source parts (spec)
