---
'@ai-sdk/groq': patch
---

feat (provider/groq): add llama 4 model
