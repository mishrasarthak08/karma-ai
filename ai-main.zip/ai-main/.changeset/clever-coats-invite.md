---
'@ai-sdk/provider': patch
---

release alpha.4
