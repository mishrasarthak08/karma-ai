---
'@ai-sdk/openai': patch
---

feat(provider/openai): add o3 & o4-mini with developer systemMessageMode
