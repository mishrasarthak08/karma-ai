---
'ai': patch
---

chore(ui-utils): merge into ai package
