---
'@ai-sdk/provider': major
---

chore (provider): merge rawRequest into request (language model v2)
