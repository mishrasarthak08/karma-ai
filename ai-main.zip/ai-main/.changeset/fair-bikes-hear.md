---
'@ai-sdk/svelte': major
'@ai-sdk/react': major
'ai': major
---

chore (ui): inline/remove ChatRequest type
