---
'ai': patch
---

feat (ai): support system parameter in Agent constructor
