---
'ai': major
---

chore (ai): remove deprecated experimental_providerMetadata
