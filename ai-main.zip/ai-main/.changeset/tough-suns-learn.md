---
'@ai-sdk/provider-utils': patch
---

refactoring: move tools helper into provider-utils
