---
'ai': major
---

chore (ai): rename UIMessageStreamPart to UIMessageChunk
