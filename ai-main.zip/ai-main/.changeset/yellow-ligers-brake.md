---
'@ai-sdk/xai': patch
---

feat (providers/xai): add grok-3 models
