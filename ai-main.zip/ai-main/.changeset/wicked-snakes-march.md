---
'@ai-sdk/openai': patch
---

Fix PDF file parts when passed as a string url or Uint8Array
