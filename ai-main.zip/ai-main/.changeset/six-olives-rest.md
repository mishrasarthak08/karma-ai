---
'@ai-sdk/anthropic': patch
---

feat (providers/anthropic): add claude v4 models
