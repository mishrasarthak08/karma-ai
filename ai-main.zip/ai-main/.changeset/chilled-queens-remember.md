---
'@ai-sdk/provider': major
---

chore (provider): cleanup request and rawRequest (language model v2)
