---
'@ai-sdk/gateway': patch
---

chore (providers/gateway): update language model ids
