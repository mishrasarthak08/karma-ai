---
'ai': patch
---

fix (core): improve error handling in streamText's consumeStream method
