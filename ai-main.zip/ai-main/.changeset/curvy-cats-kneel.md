---
'ai': patch
---

feat (ai): add ignoreIncompleteToolCalls option to convertToModelMessages
