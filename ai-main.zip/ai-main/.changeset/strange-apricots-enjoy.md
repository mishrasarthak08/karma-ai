---
'@ai-sdk/groq': patch
---

chore(providers/groq): convert to providerOptions
