---
'ai': patch
---

fix (ui): do not send changing assistant message ids when onFinish is provided
