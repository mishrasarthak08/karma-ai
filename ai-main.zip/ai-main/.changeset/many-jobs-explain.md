---
'@ai-sdk/codemod': patch
---

release AI SDK 5.0 codemods package
