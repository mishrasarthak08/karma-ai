---
'@ai-sdk/provider': major
---

chore (provider): remove mode
