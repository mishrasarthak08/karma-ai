---
'ai': patch
---

feat (ai): add array support to stopWhen
