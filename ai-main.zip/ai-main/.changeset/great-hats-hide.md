---
'ai': patch
---

fix (ai): respect content order in toResponseMessages
