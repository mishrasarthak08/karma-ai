---
'@ai-sdk/openai': patch
---

Add missing file_search tool support to OpenAI Responses API
