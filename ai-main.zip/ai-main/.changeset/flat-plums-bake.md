---
'ai': minor
---

feat (core): Add finishReason field to NoObjectGeneratedError
