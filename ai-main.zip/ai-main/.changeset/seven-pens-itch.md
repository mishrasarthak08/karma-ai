---
'@ai-sdk/provider-utils': patch
---

chore (utils): remove unused test helpers
