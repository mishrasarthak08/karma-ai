---
'ai': patch
---

feat (ui): add onData callback to Chat
