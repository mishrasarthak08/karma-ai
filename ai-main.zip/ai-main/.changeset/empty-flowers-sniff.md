---
'@ai-sdk/google': patch
---

update supportedUrls to only support native URL
