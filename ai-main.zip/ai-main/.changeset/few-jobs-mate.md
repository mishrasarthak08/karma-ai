---
'@ai-sdk/svelte': major
'@ai-sdk/react': major
'@ai-sdk/vue': major
'ai': major
---

chore (ui): remove managed chat inputs
