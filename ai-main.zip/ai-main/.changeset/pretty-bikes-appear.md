---
'ai': patch
---

fix (ai/mcp): better support for zero-argument MCP tools
