---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/google-vertex': patch
'@ai-sdk/togetherai': patch
'@ai-sdk/deepinfra': patch
'@ai-sdk/fireworks': patch
'@ai-sdk/replicate': patch
'@ai-sdk/luma': patch
'@ai-sdk/fal': patch
'ai': patch
---

fix (image-model): `specificationVersion: v1` -> `v2`
