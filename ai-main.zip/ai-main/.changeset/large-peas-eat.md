---
'ai': major
---

chore (ai): remove `data` and `allowEmptySubmit` from `ChatRequestOptions`
