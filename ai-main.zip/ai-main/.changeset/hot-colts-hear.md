---
'ai': patch
---

feat (ai): improve prompt validation error message
