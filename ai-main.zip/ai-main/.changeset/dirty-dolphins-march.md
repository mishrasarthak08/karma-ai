---
'@ai-sdk/provider-utils': patch
---

chore (provider-utils): update eventsource-parser to 3.0.3
