---
'ai': patch
---

feat(smooth-stream): chunking callbacks
