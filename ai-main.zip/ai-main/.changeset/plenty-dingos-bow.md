---
'ai': patch
---

feat (ai): allow sync prepareStep
