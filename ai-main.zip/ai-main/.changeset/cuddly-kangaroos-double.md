---
'@ai-sdk/amazon-bedrock': patch
---

chore(providers/bedrock): use camelCase for providerOptions
