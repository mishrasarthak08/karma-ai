---
'ai': major
---

chore (ai): rename reasoning to reasoningText, rename reasoningDetails to reasoning (streamText, generateText)
