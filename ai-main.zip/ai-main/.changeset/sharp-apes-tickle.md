---
'@ai-sdk/svelte': major
'@ai-sdk/react': major
'@ai-sdk/vue': major
'ai': major
---

feat (ui): use UI_MESSAGE generic
