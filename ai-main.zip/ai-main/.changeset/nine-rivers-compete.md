---
'@ai-sdk/google-vertex': patch
'@ai-sdk/google': patch
---

chore(providers/google): switch to providerOptions
