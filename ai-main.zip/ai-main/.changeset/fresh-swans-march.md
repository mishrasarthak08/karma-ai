---
'ai': major
---

chore (ai): remove getUIText helper
