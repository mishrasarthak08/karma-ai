---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): initial gateway provider
