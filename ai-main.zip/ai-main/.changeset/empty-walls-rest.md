---
'@ai-sdk/openai': patch
---

Add reasoning-part-finish parts for reasoning models in the responses API
