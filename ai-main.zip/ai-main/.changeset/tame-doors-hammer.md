---
'@ai-sdk/google': patch
---

removes (unsupported) `additionalProperties` from the Schema sent in the request payloads to Google APIs
