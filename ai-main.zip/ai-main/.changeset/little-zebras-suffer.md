---
'@ai-sdk/openai': patch
---

fix: propagate openai transcription fixes
