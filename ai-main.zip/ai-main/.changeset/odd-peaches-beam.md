---
'@ai-sdk/provider': major
---

feat: upgrade speech models to v2 specification
