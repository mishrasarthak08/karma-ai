---
'@ai-sdk/provider': major
---

chore: move warnings into stream-start part (spec)
