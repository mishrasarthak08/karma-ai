---
'@ai-sdk/openai': major
---

fix (provider/openai): default strict mode to false
