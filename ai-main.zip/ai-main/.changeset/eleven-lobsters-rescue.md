---
'@ai-sdk/provider-utils': patch
---

refactor (provider-utils): move `customAlphabet()` method from `nanoid` into codebase
