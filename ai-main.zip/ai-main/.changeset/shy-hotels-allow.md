---
'@ai-sdk/provider-utils': patch
---

feat (ai): add InferToolInput and InferToolOutput helpers
