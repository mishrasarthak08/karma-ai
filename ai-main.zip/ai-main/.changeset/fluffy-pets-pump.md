---
'@ai-sdk/openai': patch
---

adding support for gpt-4o-search-preview and handling unsupported parameters
