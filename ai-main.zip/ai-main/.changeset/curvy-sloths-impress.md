---
'@ai-sdk/provider-utils': major
---

refactoring (ai): restructure provider-defined tools
