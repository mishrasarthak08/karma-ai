---
'ai': major
---

feat (ai): replace maxSteps with continueUntil (generateText)
