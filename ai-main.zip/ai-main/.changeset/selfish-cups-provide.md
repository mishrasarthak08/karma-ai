---
'@ai-sdk/openai': patch
---

fix (provider/openai): push first reasoning chunk in output item added event
