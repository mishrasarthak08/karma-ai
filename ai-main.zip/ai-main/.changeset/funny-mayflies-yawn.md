---
'ai': major
---

chore (ai): remove useChat keepLastMessageOnError
