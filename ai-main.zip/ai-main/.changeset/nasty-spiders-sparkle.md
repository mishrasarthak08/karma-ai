---
'@ai-sdk/provider': patch
'@ai-sdk/openai': patch
'ai': patch
---

core (ai): change transcription model mimeType to mediaType
