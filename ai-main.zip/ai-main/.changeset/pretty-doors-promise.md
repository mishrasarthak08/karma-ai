---
'ai': patch
---

fix (ai): send `start` part in correct position in stream (streamText)
