---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/provider-utils': patch
'@ai-sdk/google-vertex': patch
'@ai-sdk/anthropic': patch
'@ai-sdk/google': patch
'@ai-sdk/openai': patch
'ai': patch
---

fix(packages): export node10 compatible types
