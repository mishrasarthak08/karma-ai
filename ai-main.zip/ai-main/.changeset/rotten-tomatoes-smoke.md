---
'ai': major
---

chore (ui): replace chat store concept with chat instances
