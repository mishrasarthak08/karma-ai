---
'@ai-sdk/anthropic': patch
---

feat (provider/anthropic): parse websearch tool args
