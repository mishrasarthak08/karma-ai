---
'@ai-sdk/openai': patch
---

Fix streaming and reconstruction of reasoning summary parts
