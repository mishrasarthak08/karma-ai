---
'@ai-sdk/anthropic': patch
'@ai-sdk/provider': patch
---

feat(anthropic): add server-side web search support
