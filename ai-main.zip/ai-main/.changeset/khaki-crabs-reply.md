---
'@ai-sdk/google': patch
---

Support tool schemas that allow additional properties (e.g `z.record(z.string())`)
