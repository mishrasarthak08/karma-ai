---
'ai': patch
---

fix (ui/react): update messages immediately with the submitted user message
