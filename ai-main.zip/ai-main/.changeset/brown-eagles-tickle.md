---
'ai': patch
---

feat (ui): add generics to ui message stream parts
