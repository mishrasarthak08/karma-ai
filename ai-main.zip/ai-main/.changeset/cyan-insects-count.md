---
'@ai-sdk/google': patch
---

Expose raw usageMetadata returned from Google Generative AI in providerMetadata
