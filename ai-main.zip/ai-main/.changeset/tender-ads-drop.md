---
'ai': patch
---

feat (ai): export SourceDocumentUIPart
