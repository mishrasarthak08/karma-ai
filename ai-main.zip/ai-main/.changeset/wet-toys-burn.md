---
'ai': major
---

chore (ai): remove ui message data property
