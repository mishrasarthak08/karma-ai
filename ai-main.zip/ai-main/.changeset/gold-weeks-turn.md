---
'@ai-sdk/anthropic': patch
---

fix(provider/anthropic): correct Claude 4 model ID format
