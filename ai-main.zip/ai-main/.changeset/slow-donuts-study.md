---
'ai': patch
---

fix (ai): merge data ui stream parts correctly
