---
'@ai-sdk/google-vertex': patch
'@ai-sdk/anthropic': patch
---

chore(providers/anthropic): switch to providerOptions
