---
'@ai-sdk/react': patch
---

fix (react): integrate addToolResult into UseChatHelpers type without intersection
