---
'ai': patch
---

chore (ai): remove provider re-exports
