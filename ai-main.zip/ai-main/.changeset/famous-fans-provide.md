---
'ai': patch
---

chore(providers/llamaindex): extract to separate package
