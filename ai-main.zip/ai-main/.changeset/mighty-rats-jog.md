---
'ai': patch
---

Fix custom `fetch` in HttpChatTransport
