---
'@ai-sdk/provider': major
'ai': major
---

chore (provider,ai): tools have input/output instead of args,result
