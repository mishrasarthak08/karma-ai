---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): improve oidc api key client auth flow
