---
'ai': major
---

chore (ai): rename continueUntil to stopWhen. Rename maxSteps stop condition to stepCountIs.
