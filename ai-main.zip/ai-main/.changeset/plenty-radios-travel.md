---
'ai': major
---

chore (ai): refactor and use chatstore in svelte
