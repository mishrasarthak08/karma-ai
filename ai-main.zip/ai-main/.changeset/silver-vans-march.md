---
'@ai-sdk/provider': major
---

feat (provider): support reasoning tokens, cached input tokens, total token in usage information
