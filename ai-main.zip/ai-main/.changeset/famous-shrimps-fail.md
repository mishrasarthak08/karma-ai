---
'@ai-sdk/provider-utils': major
'@ai-sdk/svelte': major
'@ai-sdk/react': major
'@ai-sdk/vue': major
'ai': major
---

feat (ui): introduce ChatStore and ChatTransport
