---
'ai': major
---

feat (ai): automatic tool execution error handling
