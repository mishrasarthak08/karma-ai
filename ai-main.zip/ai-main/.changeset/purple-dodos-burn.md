---
'@ai-sdk/assemblyai': patch
'@ai-sdk/elevenlabs': patch
'@ai-sdk/deepgram': patch
'@ai-sdk/gladia': patch
'@ai-sdk/revai': patch
'@ai-sdk/provider': patch
'ai': patch
---

feat: add transcription and speech model support to provider registry
