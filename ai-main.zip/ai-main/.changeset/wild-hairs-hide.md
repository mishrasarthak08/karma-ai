---
'@ai-sdk/amazon-bedrock': patch
---

Add style parameter support for Amazon Bedrock Nova Canvas image generation
