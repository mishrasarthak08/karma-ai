---
'ai': major
---

chore (ai): replace useChat attachments with file ui parts
