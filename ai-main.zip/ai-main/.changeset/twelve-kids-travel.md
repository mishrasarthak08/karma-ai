---
'ai': patch
---

chore: remove ai/react
