---
'@ai-sdk/openai': patch
---

feat (providers/openai): add gpt-image-1 model id to image settings
