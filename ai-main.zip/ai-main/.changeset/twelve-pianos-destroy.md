---
'ai': patch
---

feat (ai): allow using provider default temperature by specifying null
