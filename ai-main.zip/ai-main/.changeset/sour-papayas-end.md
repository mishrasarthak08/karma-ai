---
'ai': patch
---

fix (ui): add message metadata in Chat.sendMessage
