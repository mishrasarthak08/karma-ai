---
'@ai-sdk/gateway': patch
---

feat (provider/gateway): add grok-4 model id
