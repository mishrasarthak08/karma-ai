---
'@ai-sdk/provider-utils': major
---

chore (provider-utils): return IdGenerator interface
