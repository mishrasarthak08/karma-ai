---
'@ai-sdk/react': patch
---

fix (react): structuredClone message in replaceMessage
