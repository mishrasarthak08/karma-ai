---
'@ai-sdk/google': patch
---

feat(providers/google): Add taskType support for Text Embedding Models
