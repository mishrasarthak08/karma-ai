---
'ai': patch
---

fix (ui): inject generated response message id
