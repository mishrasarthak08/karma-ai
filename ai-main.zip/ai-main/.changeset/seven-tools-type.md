---
'ai': major
---

feat (ai): inject message id in createUIMessageStream
