---
'ai': major
---

chore (ai): restructure prepareRequest
