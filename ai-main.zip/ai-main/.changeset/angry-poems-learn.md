---
'@ai-sdk/azure': patch
---

feat (provider/azure): add OpenAI responses API support
