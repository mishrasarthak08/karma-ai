---
'ai': patch
---

feat (ai): add experimental prepareStep callback to generateText
