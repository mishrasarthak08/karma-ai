---
'@ai-sdk/openai': patch
---

chore(openai): remove legacy function calling
