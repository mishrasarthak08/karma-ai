---
'@ai-sdk/provider': major
---

refactoring (provider): restructure tool result output
