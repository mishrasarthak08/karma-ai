---
'@ai-sdk/openai': patch
---

Do not warn if empty text is the first part of a reasoning sequence
