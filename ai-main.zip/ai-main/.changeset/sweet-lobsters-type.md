---
'@ai-sdk/provider-utils': major
'ai': major
---

feat (ui): UI message metadata
