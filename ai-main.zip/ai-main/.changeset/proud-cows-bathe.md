---
'ai': major
---

chore (ai): change file to parts to use urls instead of data
