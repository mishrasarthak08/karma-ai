---
'ai': patch
---

remove deprecated `CoreTool*` types
