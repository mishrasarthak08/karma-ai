---
'@ai-sdk/provider-utils': patch
'ai': patch
---

chore(provider-utils): move ToolResultContent to provider-utils
