---
'@ai-sdk/provider': major
---

chore: restructure reasoning support
