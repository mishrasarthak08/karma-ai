---
'@ai-sdk/amazon-bedrock': patch
---

fix(provider/amazon-bedrock): use consistent document names for prompt cache effectiveness
