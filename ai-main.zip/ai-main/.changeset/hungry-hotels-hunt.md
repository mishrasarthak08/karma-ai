---
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/provider': patch
'ai': patch
---

feat(embed-many): respect supportsParallelCalls & concurrency
