---
'@ai-sdk/openai-compatible': patch
---

fix (provider/openai-compatible): change tool_call type schema to nullish
