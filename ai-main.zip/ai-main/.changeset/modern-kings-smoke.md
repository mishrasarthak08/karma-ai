---
'@ai-sdk/lmnt': patch
---

feat(providers/lmnt): add speech
