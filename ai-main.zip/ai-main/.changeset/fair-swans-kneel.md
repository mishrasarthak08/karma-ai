---
'@ai-sdk/google-vertex': patch
---

chore(providers/google-vertex): update embedding model to use providerOptions
