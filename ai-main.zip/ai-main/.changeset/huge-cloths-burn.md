---
'@ai-sdk/google': patch
---

fix (provider/google): allow "OFF" for Google HarmBlockThreshold
