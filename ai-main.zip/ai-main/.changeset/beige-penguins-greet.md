---
'@ai-sdk/deepinfra': patch
---

feat (providers/deepinfra): add llama 4 models
