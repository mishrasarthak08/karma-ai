---
'@ai-sdk/anthropic': patch
---

feat: streamText onChunk raw chunk support
