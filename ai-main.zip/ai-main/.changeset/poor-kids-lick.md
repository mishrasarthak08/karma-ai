---
'ai': major
---

chore (ai): remove sendExtraMessageFields
