---
'@ai-sdk/openai': patch
---

fix (provider/openai): correct default for chat model strict mode
