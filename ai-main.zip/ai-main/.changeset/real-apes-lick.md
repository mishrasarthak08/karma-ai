---
'ai': minor
---

feat (ai): add filename to file ui parts
