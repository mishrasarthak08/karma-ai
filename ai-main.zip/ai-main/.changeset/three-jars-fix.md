---
'@ai-sdk/openai': patch
---

fix (openai): structure output for responses model
