---
'ai': patch
---

feat (ui): resolvable header, body, credentials in http chat transport
