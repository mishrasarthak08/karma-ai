---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/google-vertex': patch
'@ai-sdk/togetherai': patch
'@ai-sdk/deepinfra': patch
'@ai-sdk/fireworks': patch
'@ai-sdk/provider': patch
'@ai-sdk/mistral': patch
'@ai-sdk/cohere': patch
'@ai-sdk/google': patch
'@ai-sdk/openai': patch
'ai': patch
---

chore(embedding-model): add v2 interface
