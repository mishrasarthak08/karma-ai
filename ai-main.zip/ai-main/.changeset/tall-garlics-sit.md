---
'ai': patch
---

feat (ui): support message replacement in chat via messageId param on sendMessage
