---
'ai': major
---

chore (ai): rename id to chatId (in post request, resume request, and useChat)
