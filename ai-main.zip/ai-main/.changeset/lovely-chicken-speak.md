---
'@ai-sdk/provider': patch
---

chore: add language setting to speechv2
