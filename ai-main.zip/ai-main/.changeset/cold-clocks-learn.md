---
'@ai-sdk/anthropic': patch
---

feat (provider/anthropic): send web search tool calls
