---
'@ai-sdk/elevenlabs': patch
---

feat (provider/elevenlabs): add transcription provider
