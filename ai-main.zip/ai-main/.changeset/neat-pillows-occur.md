---
'@ai-sdk/provider': patch
---

chore (provider): extract shared provider options and metadata (spec)
