---
'@ai-sdk/provider-utils': patch
---

chore (provider-utils): switch to standard-schema
