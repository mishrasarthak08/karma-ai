---
'@ai-sdk/openai': patch
---

feat(provider/openai): add missing reasoning models to responses API
