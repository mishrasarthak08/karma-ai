---
'@ai-sdk/openai': patch
---

chore(openai): remove simulateStreaming
