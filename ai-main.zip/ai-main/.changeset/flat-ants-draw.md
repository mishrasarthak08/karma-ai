---
'ai': patch
---

feat (ai): export mock image, speech, and transcription models
