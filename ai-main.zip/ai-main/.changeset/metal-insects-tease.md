---
'@ai-sdk/provider': major
---

chore: refactor reasoning parts (spec)
