---
'@ai-sdk/openai': patch
---

fix(providers/openai): logprobs for stream alongside completion model
