---
'@ai-sdk/perplexity': patch
---

feat (provider/perplexity): add sonar-deep-research model
