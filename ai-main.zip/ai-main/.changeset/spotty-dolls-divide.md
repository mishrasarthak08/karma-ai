---
'@ai-sdk/google': patch
---

feat(providers/google): Add support for Gemini 2.5 Pro and Gemini 2.5 Flash (now stable)
