---
'ai': patch
---

feat (ai): export Chat callback types
