---
'@ai-sdk/anthropic': patch
---

fix (provider/anthropic): send tool call id in tool-input-start chunk
