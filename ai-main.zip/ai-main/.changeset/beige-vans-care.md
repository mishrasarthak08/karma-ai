---
'@ai-sdk/mistral': patch
---

add Mistral Medium 3 model support
