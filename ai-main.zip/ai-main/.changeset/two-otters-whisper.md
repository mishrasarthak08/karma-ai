---
'ai': patch
---

feat (ai): support model message array in prompt
