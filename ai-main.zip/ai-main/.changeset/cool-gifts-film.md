---
'@ai-sdk/openai': patch
---

chore(providers/openai): update embedding model to use providerOptions
