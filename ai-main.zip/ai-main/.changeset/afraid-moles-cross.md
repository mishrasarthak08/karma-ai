---
'@ai-sdk/rsc': major
'ai': major
---

chore(@ai-sdk/rsc): extract to separate package
