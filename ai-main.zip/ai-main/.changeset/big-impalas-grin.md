---
'ai': major
---

chore (ai): remove automatic conversion of UI messages to model messages
