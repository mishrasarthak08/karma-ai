---
'@ai-sdk/anthropic': patch
---

fix (providers/anthropic): remove fine grained tool streaming beta
