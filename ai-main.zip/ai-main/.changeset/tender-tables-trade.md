---
'@ai-sdk/provider': patch
---

feat(embedding-model-v2): add providerOptions
