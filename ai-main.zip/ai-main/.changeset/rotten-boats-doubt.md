---
'@ai-sdk/react': patch
---

chore (ai/react): add experimental throttle back to useChat
