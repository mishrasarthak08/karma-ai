---
'ai': major
---

chore: rename reasoning to reasoningText etc
