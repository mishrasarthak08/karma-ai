---
'ai': major
---

chore (ai): remove deprecated useChat isLoading helper
