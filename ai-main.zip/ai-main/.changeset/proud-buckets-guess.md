---
'@ai-sdk/google': patch
---

fix (provider/google): prevent error when thinking signature is used
