---
'@ai-sdk/anthropic': patch
---

fix (provider/anthropic): streaming json output
