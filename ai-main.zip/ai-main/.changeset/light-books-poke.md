---
'ai': major
---

chore (ai): flatten ui message stream parts
