---
'@ai-sdk/react': patch
---

fix (ai/react): chat instance recreation in useChat
