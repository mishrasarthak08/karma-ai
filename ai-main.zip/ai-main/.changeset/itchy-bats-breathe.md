---
'ai': major
---

chore (ai): remove content from ui messages
