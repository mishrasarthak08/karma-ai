---
'ai': major
---

chore (ai): remove ui message toolInvocations property
