---
'@ai-sdk/openai': patch
---

chore(providers/openai-transcription): switch to providerOptions
