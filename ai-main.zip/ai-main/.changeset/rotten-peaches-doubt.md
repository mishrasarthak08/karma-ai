---
'@ai-sdk/provider': major
---

chore: refactor tool call and tool call delta parts (spec)
