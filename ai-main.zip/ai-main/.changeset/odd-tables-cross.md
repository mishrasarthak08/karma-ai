---
'@ai-sdk/google': patch
---

fix(providers/google): accept nullish in safetyRatings
