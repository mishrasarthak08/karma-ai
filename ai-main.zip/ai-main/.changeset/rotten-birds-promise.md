---
'ai': patch
---

update mcp protocol version
