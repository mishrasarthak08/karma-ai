---
'@ai-sdk/google': patch
---

chore(providers/google): update embedding model to use providerOptions
