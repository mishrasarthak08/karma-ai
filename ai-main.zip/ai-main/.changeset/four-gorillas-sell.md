---
'ai': patch
---

fix (ai): add tests and examples for openai responses
