---
'ai': patch
---

fix (ai/core): refactor `toResponseMessages` to filter out empty string/content
