---
'@ai-sdk/gladia': patch
---

feat(providers/gladia): add transcribe
