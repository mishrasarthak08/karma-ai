---
'@ai-sdk/xai': patch
---

Add native XAI chat language model implementation
