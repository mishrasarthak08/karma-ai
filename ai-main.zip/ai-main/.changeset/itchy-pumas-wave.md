---
'@ai-sdk/openai': patch
---

feat(provider/openai): add serviceTier option for flex processing
