---
'@ai-sdk/groq': patch
---

feat(providers/groq): add transcribe
