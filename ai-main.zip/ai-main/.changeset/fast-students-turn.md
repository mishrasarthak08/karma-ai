---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/xai': patch
---

fix(providers/xai): return actual usage when streaming instead of NaN
