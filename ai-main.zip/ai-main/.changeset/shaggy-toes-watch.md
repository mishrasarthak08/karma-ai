---
'@ai-sdk/amazon-bedrock': patch
---

Fixes "Extra inputs are not permitted" error when using reasoning with Bedrock
