---
'ai': major
---

chore (ai): rename CoreMessage to ModelMessage
