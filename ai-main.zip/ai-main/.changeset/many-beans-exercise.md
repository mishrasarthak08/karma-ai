---
'ai': patch
---

feat(embedding-model-v2/embedMany): add response body field
