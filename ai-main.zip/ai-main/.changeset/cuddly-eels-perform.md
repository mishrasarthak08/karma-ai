---
'ai': major
---

chore (ai): change source ui message parts to source-url
