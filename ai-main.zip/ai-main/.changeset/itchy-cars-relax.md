---
'@ai-sdk/provider': major
'ai': major
---

chore: refactor file towards source pattern (spec)
