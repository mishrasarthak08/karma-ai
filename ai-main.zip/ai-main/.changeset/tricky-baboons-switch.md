---
'ai': patch
---

feat (ai): allow sync tool.execute
