---
'@ai-sdk/provider': major
---

chore: rename mimeType to mediaType
