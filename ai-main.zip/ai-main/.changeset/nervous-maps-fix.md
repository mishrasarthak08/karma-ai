---
'@ai-sdk/provider-utils': major
---

chore (provider-utils): rename TestServerCall.requestBody to requestBodyJson
