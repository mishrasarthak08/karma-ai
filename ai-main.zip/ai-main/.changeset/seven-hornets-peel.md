---
'@ai-sdk/xai': minor
---

add live search
