---
'@ai-sdk/mistral': patch
---

chore(providers/mistral): convert to providerOptions
