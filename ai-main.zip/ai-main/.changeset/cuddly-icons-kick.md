---
'@ai-sdk/provider-utils': major
'@ai-sdk/google-vertex': major
'@ai-sdk/anthropic': major
'@ai-sdk/react': major
'@ai-sdk/vue': major
'ai': major
'@ai-sdk/amazon-bedrock': major
'@ai-sdk/azure': major
'@ai-sdk/cerebras': major
'@ai-sdk/codemod': major
'@ai-sdk/cohere': major
'@ai-sdk/deepinfra': major
'@ai-sdk/deepseek': major
'@ai-sdk/fal': major
'@ai-sdk/fireworks': major
'@ai-sdk/google': major
'@ai-sdk/groq': major
'@ai-sdk/luma': major
'@ai-sdk/mistral': major
'@ai-sdk/openai': major
'@ai-sdk/openai-compatible': major
'@ai-sdk/perplexity': major
'@ai-sdk/provider': major
'@ai-sdk/replicate': major
'@ai-sdk/svelte': major
'@ai-sdk/togetherai': major
'@ai-sdk/valibot': major
'@ai-sdk/xai': major
---

AI SDK 5
