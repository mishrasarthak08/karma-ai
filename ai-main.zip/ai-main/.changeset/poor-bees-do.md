---
'ai': patch
---

feat (ai): improved error messages when using gateway
