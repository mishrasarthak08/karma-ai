---
'@ai-sdk/provider': patch
---

feat: `ImageModelV2#maxImagesPerCall` can be set to a function that returns a `number` or `undefined`, optionally as a promise

pull request: https://github.com/vercel/ai/pull/6343
