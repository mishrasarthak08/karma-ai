---
'@ai-sdk/provider': patch
---

update to LanguageModelV2ProviderDefinedClientTool to add server side tool later on
