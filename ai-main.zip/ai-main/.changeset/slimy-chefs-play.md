---
'@ai-sdk/fal': patch
---

fix (providers/fal): improve model compatibility
