---
'@ai-sdk/anthropic': patch
---

Add support for URL-based PDF documents in the Anthropic provider
