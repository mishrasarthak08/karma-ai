---
'ai': major
---

chore (ai): rename reasoning UI parts 'reasoning' property to 'text'
