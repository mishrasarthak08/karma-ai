---
'@ai-sdk/provider': major
---

chore: refactor text parts (spec)
