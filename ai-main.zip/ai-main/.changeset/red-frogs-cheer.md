---
'ai': major
---

feat (ai): streamText/generateText: totalUsage contains usage for all steps. usage is for a single step.
