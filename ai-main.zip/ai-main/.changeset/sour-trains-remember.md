---
'@ai-sdk/vue': major
---

chore (ui/vue): replace useChat with new Chat
