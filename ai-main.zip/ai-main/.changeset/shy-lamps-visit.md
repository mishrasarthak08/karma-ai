---
'@ai-sdk/provider-utils': patch
'@ai-sdk/valibot': patch
'ai': patch
---

chore(provider-utils): move over jsonSchema
