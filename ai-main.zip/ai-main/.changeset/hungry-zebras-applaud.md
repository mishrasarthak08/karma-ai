---
'ai': patch
---

remove deprecated `experimental_wrapLanguageModel`
