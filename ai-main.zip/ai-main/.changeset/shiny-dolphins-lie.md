---
'ai': major
---

chore (ai): always stream tool calls
