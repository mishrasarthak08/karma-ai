---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): include deployment and request id
