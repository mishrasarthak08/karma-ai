---
'ai': major
---

feat (ai): use console.error as default error handler for streamText and streamObject
