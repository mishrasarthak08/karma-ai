---
'@ai-sdk/openai-compatible': patch
---

chore(openai-compatible): remove simulateStreaming
