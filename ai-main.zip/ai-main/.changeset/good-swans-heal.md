---
'ai': major
---

chore (ai): improve consistency of generate text result, stream text result, and step result
