---
'@ai-sdk/assemblyai': patch
---

feat(providers/assemblyai): add transcribe
