---
'ai': patch
---

fix(ai): Unexpected reasoning-start event in extract reasoning middleware
