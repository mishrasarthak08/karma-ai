---
'ai': patch
---

fix (core): send buffered text in smooth stream when stream parts change
