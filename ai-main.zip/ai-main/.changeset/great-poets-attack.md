---
'@ai-sdk/openai': patch
---

feat (providers/openai): add o3 and o4-mini models
