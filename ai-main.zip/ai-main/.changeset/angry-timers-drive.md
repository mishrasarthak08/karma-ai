---
'@ai-sdk/google-vertex': patch
---

feat (provider/google-vertex): add imagen-3.0-generate-002
