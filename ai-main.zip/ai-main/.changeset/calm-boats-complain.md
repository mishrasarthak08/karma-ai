---
'@ai-sdk/provider': major
---

chore: restructure language model supported urls
