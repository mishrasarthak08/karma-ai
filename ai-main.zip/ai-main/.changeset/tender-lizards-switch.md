---
'ai': major
---

chore (ui): rename RequestOptions to CompletionRequestOptions
