---
'ai': major
---

chore (ai): remove StreamData and mergeStreams
