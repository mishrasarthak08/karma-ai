---
'@ai-sdk/provider': major
---

chore: remove logprobs
