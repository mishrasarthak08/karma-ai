---
'@ai-sdk/xai': patch
---

fix(providers/xai): edit supported models for structured output
