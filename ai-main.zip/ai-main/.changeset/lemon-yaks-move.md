---
'@ai-sdk/mistral': patch
---

feat(mistral): added magistral reasoning models
