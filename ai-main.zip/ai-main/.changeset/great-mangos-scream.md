---
'ai': patch
---

chore (ai): move maxSteps into UseChatOptions
