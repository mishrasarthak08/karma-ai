---
'ai': patch
---

fix (ui): avoid caching globalThis.fetch in case it is patched by other libraries
