---
'ai': patch
---

chore (ai/mcp): add `assertCapability` method to experimental MCP client
