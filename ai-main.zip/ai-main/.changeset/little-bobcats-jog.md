---
'ai': minor
---

feat (ai): add content to streamText result
