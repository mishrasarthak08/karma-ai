---
'@ai-sdk/react': patch
---

feat (ui/react): support resuming an ongoing stream
