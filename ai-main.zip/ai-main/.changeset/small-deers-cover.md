---
'@ai-sdk/provider-utils': patch
---

fix (provider-utils): detect failed fetch in browser environments
