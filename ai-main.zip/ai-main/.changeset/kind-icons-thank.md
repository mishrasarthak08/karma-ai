---
'@ai-sdk/openai-compatible': patch
---

allow any string as reasoningEffort
