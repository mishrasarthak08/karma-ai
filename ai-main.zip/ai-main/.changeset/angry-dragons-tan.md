---
'@ai-sdk/provider': major
---

feat: forward id, streaming start, streaming end of content blocks
