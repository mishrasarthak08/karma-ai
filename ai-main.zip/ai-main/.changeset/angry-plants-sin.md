---
'@ai-sdk/amazon-bedrock': patch
---

chore(providers/bedrock): convert to providerOptions
