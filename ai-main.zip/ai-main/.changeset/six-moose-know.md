---
'ai': patch
---

fix(ai/core): properly handle custom separator in provider registry
