---
'ai': patch
---

fix (ui): tool input can be undefined during input-streaming
