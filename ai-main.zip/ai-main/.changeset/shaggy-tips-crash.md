---
'@ai-sdk/google': patch
---

feat (provider/google): Change to provider defined tools

- Change the google search tool to be a provider defined tool
- Added new URL context tool as a provider defined tool
