---
'@ai-sdk/rsc': patch
'ai': patch
---

chore (rsc): move HANGING_STREAM_WARNING_TIME constant into @ai-sdk/rsc package
