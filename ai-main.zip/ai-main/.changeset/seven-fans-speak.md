---
'ai': major
---

feat (ui): extended regenerate support
