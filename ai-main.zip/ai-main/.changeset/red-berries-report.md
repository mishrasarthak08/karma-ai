---
'@ai-sdk/openai': patch
---

feat (provider/openai): add support for encrypted_reasoning to responses api
