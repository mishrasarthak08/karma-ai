---
'ai': major
---

feat (ai): simplify default provider setup
