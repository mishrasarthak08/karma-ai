---
'@ai-sdk/react': major
'@ai-sdk/vue': major
'ai': major
---

chore (ui): remove useAssistant hook (**breaking change**)
