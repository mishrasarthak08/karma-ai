---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/google-vertex': patch
'@ai-sdk/togetherai': patch
'@ai-sdk/deepinfra': patch
'@ai-sdk/fireworks': patch
'@ai-sdk/replicate': patch
'@ai-sdk/provider': patch
'@ai-sdk/openai': patch
'@ai-sdk/azure': patch
'@ai-sdk/luma': patch
'@ai-sdk/fal': patch
'@ai-sdk/xai': patch
'ai': patch
---

refactor (image-model): rename `ImageModelV1` to `ImageModelV2`
