---
'ai': patch
---

feat (ai): add experimental Agent abstraction
