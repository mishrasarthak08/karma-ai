---
'@ai-sdk/gateway': patch
---

feat (providers/gateway): share common gateway error transform logic
