---
'ai': patch
---

Allow destructuring output and errorText on `ToolUIPart` type
