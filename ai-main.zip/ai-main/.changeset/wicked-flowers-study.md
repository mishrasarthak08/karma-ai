---
'@ai-sdk/anthropic': patch
'@ai-sdk/provider': patch
'@ai-sdk/google': patch
'@ai-sdk/openai': patch
'ai': patch
---

feat(tool-calling): don't require the user to have to pass parameters
