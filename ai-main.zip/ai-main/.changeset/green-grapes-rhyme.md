---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/openai': patch
'@ai-sdk/azure': patch
---

chore(providers/openai): update completion model to use providerOptions
