---
'ai': patch
---

fix (ai/mcp): prevent mutation of customEnv
