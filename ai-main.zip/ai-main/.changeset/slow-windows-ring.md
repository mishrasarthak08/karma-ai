---
'@ai-sdk/gateway': patch
---

chore (providers/gateway): update chat model ids
