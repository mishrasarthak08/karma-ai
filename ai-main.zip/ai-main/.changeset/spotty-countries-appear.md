---
'ai': patch
---

fix (ai): catch errors in ui message stream
