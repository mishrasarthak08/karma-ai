---
'@ai-sdk/google': patch
---

fix: remove non-functional models
