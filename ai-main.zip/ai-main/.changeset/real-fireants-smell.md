---
'ai': major
---

chore (ai): rename DataStreamToSSETransformStream to JsonToSseTransformStream
