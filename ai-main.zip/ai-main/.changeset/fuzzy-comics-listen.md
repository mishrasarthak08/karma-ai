---
'ai': minor
---

feat (ai): add content to generateText result
