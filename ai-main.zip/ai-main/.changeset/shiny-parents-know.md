---
'@ai-sdk/valibot': patch
---

chore (valibot): update to valibot 1.1
