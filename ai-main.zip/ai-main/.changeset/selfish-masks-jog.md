---
'ai': patch
---

Expose provider metadata as an attribute on exported OTEL spans
