---
'ai': major
---

feat (ai): add args callbacks to tools
