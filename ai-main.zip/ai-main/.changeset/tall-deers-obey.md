---
'ai': patch
---

fix (ai): fix invalid fetch call
