---
'ai': major
---

feat (ai): add ui data parts
