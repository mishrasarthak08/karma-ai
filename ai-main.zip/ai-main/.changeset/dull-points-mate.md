---
'@ai-sdk/fal': patch
'ai': patch
---

feat(providers/fal): add transcribe
