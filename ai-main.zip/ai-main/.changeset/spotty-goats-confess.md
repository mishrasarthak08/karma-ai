---
'@ai-sdk/google': patch
---

feat(google): automatically handle system instructions for Gemma models
