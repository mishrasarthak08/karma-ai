---
'ai': major
---

fix (ai): update source url stream part
