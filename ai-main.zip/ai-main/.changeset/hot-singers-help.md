---
'ai': major
---

chore (ai): rename default provider global to AI_SDK_DEFAULT_PROVIDER
