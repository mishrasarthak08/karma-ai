---
'@ai-sdk/anthropic': patch
---

feat (provider/anthropic): json response schema support via tool calls
