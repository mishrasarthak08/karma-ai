---
'@ai-sdk/provider-utils': patch
---

refactoring: introduce FlexibleSchema
