---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/amazon-bedrock': patch
'@ai-sdk/togetherai': patch
'@ai-sdk/deepinfra': patch
'@ai-sdk/fireworks': patch
'@ai-sdk/cerebras': patch
'@ai-sdk/deepseek': patch
'@ai-sdk/xai': patch
---

feat(providers/openai-compatible): convert to providerOptions
