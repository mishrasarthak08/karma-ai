---
'@ai-sdk/anthropic': patch
---

feat(provider/anthropic): add PDF citation support with document sources for streamText
