---
'ai': patch
---

chore (ai): use JSONValue definition from provider
