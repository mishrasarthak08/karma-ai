---
'@ai-sdk/openai': patch
---

fix (provider/openai): increase transcription model resilience
