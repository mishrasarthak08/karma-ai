---
'@ai-sdk/llamaindex': patch
'@ai-sdk/langchain': patch
'ai': patch
---

chore (ai): push stream-callbacks into langchain/llamaindex adapters
