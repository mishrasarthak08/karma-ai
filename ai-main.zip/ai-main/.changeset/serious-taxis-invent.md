---
'@ai-sdk/provider': major
---

chore: refactor file parts (spec)
