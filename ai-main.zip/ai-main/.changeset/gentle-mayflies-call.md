---
'ai': patch
---

feat (ui): add onFinish to createUIMessageStream
