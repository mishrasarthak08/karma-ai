---
'@ai-sdk/google': patch
---

feat (provider/google): add new gemini models
