---
'@ai-sdk/provider': major
---

chore (provider): refactor usage (language model v2)
