---
'@ai-sdk/openai': patch
---

fix(providers/openai): zod parse error with function
