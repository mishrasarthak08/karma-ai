---
'@ai-sdk/provider': major
---

feat (provider): add name for provider defined tools for future validation
