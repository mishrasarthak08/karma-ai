---
'@ai-sdk/provider': patch
---

chore (provider): change getSupportedUrls to supportedUrls (language model v2)
