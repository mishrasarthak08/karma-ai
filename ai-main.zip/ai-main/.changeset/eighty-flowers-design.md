---
'ai': patch
---

feat (ai): expose ui message stream headers
