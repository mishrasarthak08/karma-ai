---
'ai': patch
---

chore (ai): make ui stream parts value optional when it's not required
