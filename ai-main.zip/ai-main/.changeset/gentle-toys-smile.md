---
'ai': patch
---

fix(utils/detect-mimetype): add support for detecting id3 tags
