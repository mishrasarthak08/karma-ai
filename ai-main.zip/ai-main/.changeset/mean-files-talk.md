---
'ai': patch
---

feat (ai): add data ui part schemas
