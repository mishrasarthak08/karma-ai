---
'ai': major
---

chore (ai): remove experimental continueSteps
