---
'@ai-sdk/fal': patch
---

feat (fal): Set `.providerMetaData` for image model responses
