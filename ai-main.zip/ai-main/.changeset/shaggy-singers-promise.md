---
'@ai-sdk/provider-utils': patch
---

fix(provider-utils): fix SSE parser bug (CRLF)
