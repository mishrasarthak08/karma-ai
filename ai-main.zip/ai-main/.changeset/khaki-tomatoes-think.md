---
'ai': patch
---

fix (ai): do not send id with start unless specified
