---
'@ai-sdk/provider': major
---

feat (provider): support changing provider, model, supportedUrls in middleware
