---
'@ai-sdk/vue': major
---

chore (ai): refactor and use chatstore in vue
