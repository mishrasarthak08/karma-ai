---
'ai': patch
---

feat (ai): expose http chat transport type
