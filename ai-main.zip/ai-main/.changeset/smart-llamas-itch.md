---
'@ai-sdk/provider': major
---

feat: upgrade transcription models to v2 specification
