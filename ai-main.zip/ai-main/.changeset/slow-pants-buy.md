---
'@ai-sdk/amazon-bedrock': patch
---

chore(providers/bedrock): update embedding model to use providerOptions
