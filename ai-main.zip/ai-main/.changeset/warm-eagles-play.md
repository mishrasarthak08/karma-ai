---
'ai': patch
---

fix (ai/telemetry): Avoid JSON.stringify on Uint8Arrays for telemetry
