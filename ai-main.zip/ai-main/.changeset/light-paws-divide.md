---
'@ai-sdk/provider': major
---

chore (ai): remove v1 providers
