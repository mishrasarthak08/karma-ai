---
'@ai-sdk/openai-compatible': patch
'@ai-sdk/google-vertex': patch
'@ai-sdk/provider': patch
'@ai-sdk/mistral': patch
'@ai-sdk/cohere': patch
'@ai-sdk/google': patch
'@ai-sdk/openai': patch
---

feat(embedding-model-v2): add response body field
