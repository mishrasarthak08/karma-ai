---
'ai': patch
---

feat (ai): introduce GLOBAL_DEFAULT_PROVIDER
