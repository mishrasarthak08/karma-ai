---
'ai': major
---

chore (ai): remove onResponse callback
