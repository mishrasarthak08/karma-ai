---
'@ai-sdk/provider-utils': major
---

remove deprecated `CoreToolCall` and `CoreToolResult` types
