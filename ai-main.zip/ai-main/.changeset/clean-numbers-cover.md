---
'@ai-sdk/provider-utils': patch
---

feat(provider-utils): add TestServerCall#requestCredentials
