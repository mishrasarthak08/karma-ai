---
'@ai-sdk/google-vertex': patch
'@ai-sdk/google': patch
---

feat: add provider option schemas for vertex imagegen and google genai
