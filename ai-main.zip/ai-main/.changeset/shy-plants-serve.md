---
'@ai-sdk/anthropic': patch
---

feat(anthropic): add text_editor_20250429 tool for Claude 4 models
