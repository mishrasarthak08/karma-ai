---
'ai': patch
---

fix (ai): use user-provided media type when available
