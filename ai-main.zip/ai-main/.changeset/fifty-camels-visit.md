---
'@ai-sdk/azure': patch
---

feat(providers/azure): add transcribe
