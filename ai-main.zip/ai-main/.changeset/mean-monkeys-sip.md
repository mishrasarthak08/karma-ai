---
'@ai-sdk/openai': patch
---

feat (providers/openai): add support for reasoning summaries
