---
'ai': patch
---

feat(ai): Record tool call errors on tool call spans recorded in `generateText` and `streamText`.
