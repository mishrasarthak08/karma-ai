---
'ai': major
---

chore (ai): remove StreamCallbacks.onCompletion
