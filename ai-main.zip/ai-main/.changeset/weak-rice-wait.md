---
'@ai-sdk/anthropic': patch
---

fix: anthropic computer tool
