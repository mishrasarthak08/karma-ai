---
'@ai-sdk/provider': major
---

chore (provider): remove prompt type from language model v2 spec
