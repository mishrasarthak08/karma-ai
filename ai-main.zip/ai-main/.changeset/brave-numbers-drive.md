---
'@ai-sdk/openai': patch
---

feat (provider/openai): o4 updates for responses api
