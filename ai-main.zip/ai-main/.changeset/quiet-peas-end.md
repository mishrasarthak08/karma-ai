---
'ai': patch
---

feat (ui): transient data parts
