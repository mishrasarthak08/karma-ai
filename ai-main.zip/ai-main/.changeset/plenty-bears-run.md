---
'ai': major
---

chore (ui): data stream protocol v2 with SSEs
