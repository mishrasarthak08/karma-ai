---
'ai': patch
---

chore(ai/generateObject): simplify function signature
