---
'@ai-sdk/anthropic': patch
'@ai-sdk/openai': patch
---

refactor: updated openai + anthropic tool use server side
